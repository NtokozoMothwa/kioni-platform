# KIONI Admin Panel Guide

## Admin Login Credentials

```
Email:    admin@kioni.local
Username: admin
Password: Kioni@Admin2025
```

## How to Access Admin Panel

1. **Login**: Go to `/auth/login` and use admin credentials above
2. **Admin Dashboard**: After login, navigate to `/admin/dashboard`
   - Direct URL: `http://localhost:5000/admin/dashboard`

## Admin Features

### 1. Admin Dashboard (`/admin/dashboard`)
- **Overview Statistics**:
  - Total Users count
  - Total Scans count
  - System Status
- **Quick Actions**: Direct links to user management and audit logs

### 2. User Management (`/admin/users`)
**View all registered users** with the following capabilities:
- **View User Info**: Email, username, role, join date
- **Promote/Demote Users**: Toggle admin role with one click
- **Delete Users**: Permanently remove user accounts and their associated scans
- **Safety Features**: Cannot delete your own admin account

**User Table Shows**:
- Username
- Email address
- Current role (Admin or User)
- Account creation date
- Action buttons for management

### 3. Audit Logs Viewer (`/admin/audit-logs`)
**Track all system security events** with filtering:
- **Filter by Type**:
  - All: View all events
  - Auth: Login, registration, token events
  - Scan: Threat assessment activities
  - Admin: Administrative actions
  - Error: System errors and failures

**Log Features**:
- Real-time log streaming (up to 500 entries)
- Timestamp for each event
- Color-coded event types (red for errors, gold for admin, cyan for auth)
- Easy-to-read format with line breaks

## Admin Capabilities

### User Management
- ✅ View all users in the system
- ✅ Promote regular users to admin role
- ✅ Demote admin users back to regular users
- ✅ Delete user accounts permanently
- ✅ View user creation dates
- ✅ All actions logged to audit trail

### System Monitoring
- ✅ Monitor all authentication events (registrations, logins, failures)
- ✅ Track security events and unauthorized access attempts
- ✅ View scan activities and threat assessments
- ✅ Monitor all admin actions with timestamps
- ✅ Filter logs by event type
- ✅ Access up to 500 latest log entries

### Security Features
- ✅ Admin-only access with JWT verification
- ✅ Role-based access control at database level
- ✅ All admin actions logged to `scan_audit.log`
- ✅ Cannot delete own admin account (safety mechanism)
- ✅ Admin endpoints protected with `@require_admin` decorator

## Admin Interface Features

### Separate Admin Layout
- ✅ Dedicated admin sidebar navigation
- ✅ Premium UI with Indigo + Cyan + Gold branding
- ✅ Glassmorphic design matching platform aesthetic
- ✅ Quick navigation between all admin sections
- ✅ "Return to App" button to go back to user interface
- ✅ Logout button for security

### Protected Routes
- ✅ Only admin users can access `/admin/*` pages
- ✅ Non-admin users receive access denied message
- ✅ All admin API endpoints require `@require_admin` decorator
- ✅ JWT token validated on every admin request
- ✅ Comprehensive error handling

## API Endpoints (Admin-Only)

```
GET    /admin/users              - List all users
PUT    /admin/users/{id}         - Update user (promote/demote)
DELETE /admin/users/{id}         - Delete user
GET    /admin/audit-logs         - Retrieve audit logs
```

All endpoints require:
- Valid JWT token in `Authorization: Bearer {token}` header
- User must have `is_admin=true` in database

## Admin Actions Logging

Every admin action is automatically logged with:
- Timestamp
- Action type (USER_REGISTERED, USER_LOGIN, ADMIN_ACTION, etc.)
- Admin user ID
- Affected resource ID
- Complete audit trail for compliance

## Best Practices

1. **Never share admin credentials** - Account is for authorized administrators only
2. **Review audit logs regularly** - Monitor for suspicious activities
3. **Careful with deletions** - User deletion is permanent and removes all their scans
4. **Limited admin accounts** - Only promote trusted users to admin role
5. **Test in development first** - Always test changes in dev environment before production

## Troubleshooting

**Admin panel not loading?**
- Verify you're logged in with admin account
- Check browser console for errors
- Ensure both frontend (port 5000) and backend (port 6000) are running

**Can't see users?**
- Verify admin credentials are correct
- Check that auth token is valid (24-hour expiry)
- Ensure database connection is active

**Audit logs empty?**
- Logs only show activities since server started
- First login generates initial logs
- Check `scanner_service/scan_audit.log` file directly

## Security Considerations

- Admin passwords should be changed in production
- JWT secret should be updated to a strong random value
- Consider implementing 2FA for admin accounts
- Regular audit log reviews recommended
- Keep admin account credentials secure and never share
