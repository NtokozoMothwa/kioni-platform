import { useRouter } from 'next/router';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function AdminLayout({ children }) {
  const { user, logout } = useAuth();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  if (!user?.is_admin) {
    return (
      <div className="min-h-screen bg-kioni-indigo flex items-center justify-center">
        <div className="text-center">
          <p className="text-kioni-cyan text-xl mb-4">Admin access required</p>
          <button
            onClick={() => router.push('/')}
            className="px-6 py-3 bg-kioni-cyan text-kioni-indigo rounded-lg font-semibold hover:bg-kioni-gold transition"
          >
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kioni-indigo">
      {/* Admin Header */}
      <header className="bg-kioni-indigo-dark border-b border-kioni-cyan/30 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-kioni-cyan to-kioni-gold rounded-lg flex items-center justify-center">
              <span className="text-kioni-indigo font-bold">⚙</span>
            </div>
            <h1 className="text-2xl font-bold text-white">KIONI Admin</h1>
          </div>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="text-kioni-cyan hover:text-kioni-gold transition"
          >
            {user.username} ▼
          </button>
        </div>
      </header>

      {/* Sidebar + Content */}
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-kioni-indigo-dark border-r border-kioni-cyan/30 min-h-[calc(100vh-80px)] p-6">
          <nav className="space-y-3">
            <Link href="/admin/dashboard">
              <motion.a
                whileHover={{ x: 5 }}
                className={`block px-4 py-3 rounded-lg transition-all ${
                  router.pathname === '/admin/dashboard'
                    ? 'bg-kioni-cyan/20 text-kioni-cyan border-l-2 border-kioni-cyan'
                    : 'text-slate-300 hover:text-kioni-cyan hover:bg-slate-800/50'
                }`}
              >
                📊 Dashboard
              </motion.a>
            </Link>
            <Link href="/admin/users">
              <motion.a
                whileHover={{ x: 5 }}
                className={`block px-4 py-3 rounded-lg transition-all ${
                  router.pathname === '/admin/users'
                    ? 'bg-kioni-cyan/20 text-kioni-cyan border-l-2 border-kioni-cyan'
                    : 'text-slate-300 hover:text-kioni-cyan hover:bg-slate-800/50'
                }`}
              >
                👥 User Management
              </motion.a>
            </Link>
            <Link href="/admin/audit-logs">
              <motion.a
                whileHover={{ x: 5 }}
                className={`block px-4 py-3 rounded-lg transition-all ${
                  router.pathname === '/admin/audit-logs'
                    ? 'bg-kioni-cyan/20 text-kioni-cyan border-l-2 border-kioni-cyan'
                    : 'text-slate-300 hover:text-kioni-cyan hover:bg-slate-800/50'
                }`}
              >
                📋 Audit Logs
              </motion.a>
            </Link>

            <div className="border-t border-slate-700 my-4 pt-4">
              <Link href="/">
                <a className="block px-4 py-3 text-slate-300 hover:text-kioni-gold transition rounded-lg hover:bg-slate-800/50">
                  ← Return to App
                </a>
              </Link>
              <button
                onClick={() => {
                  logout();
                  router.push('/auth/login');
                }}
                className="w-full mt-2 px-4 py-3 bg-red-900/50 text-red-300 hover:bg-red-900 rounded-lg transition"
              >
                🚪 Logout
              </button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
