import jsPDF from "jspdf";
import "jspdf-autotable";

// ───────── CSV Report ─────────
export function generateCSV(scanData) {
  const rows = [
    ["Target", scanData.title],
    ["Risk Score", scanData.riskScore],
    ["Status", scanData.status],
    ["Date", new Date().toLocaleString()]
  ];

  let csv = rows.map(e => e.join(",")).join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = `${scanData.title}-kioni-report.csv`;
  a.click();
}

// ───────── PDF Report ─────────
export function generatePDF(scanData) {
  const doc = new jsPDF();

  // Title
  doc.setFontSize(22);
  doc.text("Kioni Cyber Risk Report", 14, 20);
  doc.setFontSize(12);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 28);

  // Table
  doc.autoTable({
    startY: 40,
    head: [["Field", "Value"]],
    body: [
      ["Target", scanData.title],
      ["Risk Score", scanData.riskScore],
      ["Status", scanData.status],
      ["Severity", scanData.riskScore > 70 ? "High" : scanData.riskScore > 40 ? "Medium" : "Low"],
    ]
  });

  // AI Summary
  const summary = scanData.riskScore > 50
    ? "Immediate action recommended: close vulnerable ports, update firewall, and verify server configuration."
    : "No major issues detected. Maintain regular security checks.";

  doc.text("AI Security Summary:", 14, doc.lastAutoTable.finalY + 15);
  doc.text(summary, 14, doc.lastAutoTable.finalY + 25);

  doc.save(`${scanData.title}-kioni-report.pdf`);
}
