import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export const generateSecurityReport = (scanData, reportName = 'Security Report') => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // Colors
  const primaryColor = [14, 14, 44]; // Deep Indigo
  const accentColor = [0, 229, 255]; // Cyan
  const goldColor = [243, 198, 35]; // Gold

  // Add header with KIONI branding
  doc.setFillColor(...primaryColor);
  doc.rect(0, 0, 210, 40, 'F');

  // Title
  doc.setTextColor(243, 198, 35); // Gold
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  doc.text('KIONI', 15, 20);

  // Tagline
  doc.setTextColor(255, 255, 255); // White
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Intelligence for a Safer, Smarter Africa', 15, 28);

  // Report title
  doc.setTextColor(14, 14, 44); // Dark Indigo
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text(reportName, 15, 50);

  // Generated date
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`, 15, 57);

  let yPosition = 65;

  // Summary Section
  if (scanData) {
    doc.setFillColor(240, 240, 240);
    doc.rect(15, yPosition - 3, 180, 8, 'F');
    
    doc.setTextColor(14, 14, 44);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('Executive Summary', 15, yPosition + 2);
    
    yPosition += 15;

    // Summary data in boxes
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(50, 50, 50);

    const summaryItems = [
      { label: 'Target', value: scanData.title || 'N/A' },
      { label: 'Scan Date', value: scanData.timestamp ? new Date(scanData.timestamp).toLocaleDateString() : 'N/A' },
      { label: 'Status', value: scanData.status || 'Complete' },
    ];

    summaryItems.forEach((item, index) => {
      doc.text(`${item.label}:`, 20, yPosition + (index * 8));
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(0, 100, 200);
      doc.text(String(item.value), 60, yPosition + (index * 8));
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(50, 50, 50);
    });

    yPosition += 35;
  }

  // Findings Section
  doc.setFillColor(240, 240, 240);
  doc.rect(15, yPosition - 3, 180, 8, 'F');
  
  doc.setTextColor(14, 14, 44);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('Key Findings', 15, yPosition + 2);
  
  yPosition += 12;

  // Findings table
  const findingsData = [
    ['Metric', 'Value', 'Status'],
    ['Open Ports', String(scanData?.openPorts || 0), scanData?.openPorts > 5 ? '⚠️ High' : '✓ Normal'],
    ['Risk Score', `${scanData?.riskScore || 0}%`, getRiskLevel(scanData?.riskScore)],
    ['Overall Status', 'Security Assessment', scanData?.status || 'Complete'],
  ];

  autoTable(doc, {
    startY: yPosition,
    head: [findingsData[0]],
    body: findingsData.slice(1),
    headStyles: {
      fillColor: accentColor,
      textColor: primaryColor,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      textColor: 50,
      lineColor: 200
    },
    alternateRowStyles: {
      fillColor: [250, 250, 250]
    },
    margin: { left: 15, right: 15 }
  });

  yPosition = doc.lastAutoTable.finalY + 15;

  // Recommendations Section
  doc.setFillColor(240, 240, 240);
  doc.rect(15, yPosition - 3, 180, 8, 'F');
  
  doc.setTextColor(14, 14, 44);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('Recommendations', 15, yPosition + 2);
  
  yPosition += 12;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(50, 50, 50);

  const recommendations = getRecommendations(scanData);
  
  recommendations.forEach((rec, index) => {
    const lines = doc.splitTextToSize(rec, 170);
    lines.forEach((line, lineIndex) => {
      if (yPosition > 270) {
        doc.addPage();
        yPosition = 15;
      }
      doc.text(line, 20, yPosition);
      yPosition += 5;
    });
    yPosition += 3;
  });

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text(
    'KIONI - Confidential Security Report',
    15,
    doc.internal.pageSize.getHeight() - 10
  );
  doc.text(
    `Page ${doc.internal.pages.length - 1}`,
    doc.internal.pageSize.getWidth() - 30,
    doc.internal.pageSize.getHeight() - 10
  );

  return doc;
};

const getRiskLevel = (riskScore) => {
  if (riskScore >= 70) return '🔴 Critical';
  if (riskScore >= 50) return '🟠 High';
  if (riskScore >= 30) return '🟡 Medium';
  return '🟢 Low';
};

const getRecommendations = (scanData) => {
  const recommendations = [];

  if (!scanData) {
    return ['Run a security scan to get personalized recommendations.'];
  }

  if (scanData.openPorts > 10) {
    recommendations.push(
      '• Close unnecessary open ports: You have ' + scanData.openPorts + ' ports open. Review each one and close any that are not in use.'
    );
  }

  if (scanData.riskScore >= 70) {
    recommendations.push(
      '• Immediate action required: Your risk score is ' + scanData.riskScore + '%. Prioritize fixing critical vulnerabilities.'
    );
    recommendations.push(
      '• Implement a Web Application Firewall (WAF) to protect against web-based attacks.'
    );
  } else if (scanData.riskScore >= 50) {
    recommendations.push(
      '• Strengthen your security posture: Focus on patching known vulnerabilities and updating software.'
    );
  }

  recommendations.push(
    '• Enable firewalls on all network interfaces and configure them with strict inbound/outbound rules.'
  );
  recommendations.push(
    '• Implement regular security updates and patch management procedures.'
  );
  recommendations.push(
    '• Monitor logs continuously for suspicious activities and set up alerts for critical events.'
  );
  recommendations.push(
    '• Consider penetration testing to identify additional security weaknesses.'
  );

  return recommendations.length > 0 ? recommendations : ['System appears secure. Continue regular monitoring.'];
};

export const downloadPDF = (doc, filename = 'security-report.pdf') => {
  doc.save(filename);
};
