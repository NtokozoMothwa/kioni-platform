export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.error("Failed to copy:", err);
    return false;
  }
}

export function formatScanData(scan) {
  return `Target: ${scan.title}
Risk Score: ${scan.riskScore}%
Open Ports: ${scan.openPorts}
Scanned: ${new Date(scan.timestamp).toLocaleString()}`;
}
