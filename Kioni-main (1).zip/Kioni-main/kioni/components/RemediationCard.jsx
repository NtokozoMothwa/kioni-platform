import React from "react";
import { motion } from "framer-motion";

export default function RemediationCard({ issue, suggestion, severity }) {
  const severityConfig = {
    High: { bg: "from-red-600 to-red-700", border: "border-red-500/50", icon: "🔴", badge: "bg-red-500/20 text-red-300" },
    Medium: { bg: "from-yellow-600 to-yellow-700", border: "border-yellow-500/50", icon: "🟡", badge: "bg-yellow-500/20 text-yellow-300" },
    Low: { bg: "from-green-600 to-green-700", border: "border-green-500/50", icon: "🟢", badge: "bg-green-500/20 text-green-300" },
  };

  const config = severityConfig[severity] || severityConfig.Low;

  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -3 }}
      whileTap={{ scale: 0.98 }}
      className={`group bg-gradient-to-br ${config.bg} p-6 rounded-2xl border ${config.border} text-white backdrop-blur-xl hover:shadow-2xl transition-all duration-300`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start gap-3 flex-1">
          <span className="text-2xl mt-0.5">{config.icon}</span>
          <div>
            <h3 className="font-bold text-lg text-white">{issue}</h3>
            <p className="text-white/80 text-sm mt-2 leading-relaxed">💡 {suggestion}</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap ml-2 ${config.badge}`}>
          {severity}
        </span>
      </div>
    </motion.div>
  );
}
