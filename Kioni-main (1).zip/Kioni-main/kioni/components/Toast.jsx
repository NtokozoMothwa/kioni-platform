import React from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Toast({ toasts }) {
  return (
    <AnimatePresence>
      <div className="fixed bottom-4 right-4 z-50 space-y-3 pointer-events-none">
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 20, x: 400 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, y: 20, x: 400 }}
            transition={{ duration: 0.3 }}
            className={`pointer-events-auto px-4 py-3 rounded-lg text-white text-sm font-medium flex items-center gap-2 ${
              toast.type === "success"
                ? "bg-green-500/90 border border-green-400/50"
                : toast.type === "error"
                ? "bg-red-500/90 border border-red-400/50"
                : "bg-blue-500/90 border border-blue-400/50"
            } backdrop-blur-md shadow-lg`}
          >
            <span>
              {toast.type === "success" ? "✅" : toast.type === "error" ? "❌" : "ℹ️"}
            </span>
            {toast.message}
          </motion.div>
        ))}
      </div>
    </AnimatePresence>
  );
}
