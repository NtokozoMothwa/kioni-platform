// Google Analytics event tracking helper
export const trackEvent = (eventName, eventParams = {}) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', eventName, eventParams)
  }
}

// Track scan completion
export const trackScanEvent = (target, riskScore, duration) => {
  trackEvent('scan_completed', {
    target: target,
    risk_score: riskScore,
    duration_ms: duration,
    event_category: 'security',
  })
}

// Track report download
export const trackReportDownload = (reportName, riskScore) => {
  trackEvent('report_downloaded', {
    report_name: reportName,
    risk_score: riskScore,
    event_category: 'reporting',
  })
}

// Track settings changes
export const trackSettingsChange = (settingName, value) => {
  trackEvent('settings_changed', {
    setting_name: settingName,
    value: value,
    event_category: 'settings',
  })
}

// Track page engagement
export const trackPageEngagement = (pageTitle, timeOnPage) => {
  trackEvent('page_engagement', {
    page_title: pageTitle,
    time_on_page: timeOnPage,
    event_category: 'engagement',
  })
}
