import React from "react";
import { motion } from "framer-motion";

export default function VerificationIndicator({ verified = true, label = "Verified" }) {
  if (!verified) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-red-300 text-sm flex items-center gap-1"
      >
        <span>●</span> Unverified
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ scale: 0, rotate: -180 }}
      animate={{ scale: 1, rotate: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 15 }}
      className="flex items-center gap-2"
    >
      <motion.div
        animate={{ rotate: [0, 10, -10, 0] }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="w-5 h-5 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 flex items-center justify-center"
      >
        <motion.span
          animate={{ scale: [0.8, 1.2, 1] }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="text-white text-sm font-bold"
        >
          ✓
        </motion.span>
      </motion.div>
      <span className="text-green-300 text-sm font-semibold">{label}</span>
    </motion.div>
  );
}
