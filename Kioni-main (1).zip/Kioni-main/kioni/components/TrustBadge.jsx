import React from "react";
import { motion } from "framer-motion";

export default function TrustBadge({ level = "High", percentage = 92 }) {
  const colors = {
    High: { bg: "from-green-500 to-emerald-600", ring: "ring-green-400" },
    Medium: { bg: "from-yellow-500 to-amber-600", ring: "ring-yellow-400" },
    Low: { bg: "from-red-500 to-rose-600", ring: "ring-red-400" }
  };

  const color = colors[level] || colors.High;

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className={`flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-br ${color.bg} ring-4 ${color.ring} shadow-lg relative`}
    >
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        className="absolute inset-0 rounded-full border-4 border-transparent border-t-white opacity-30"
      />
      <div className="relative z-10 text-center">
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-4xl font-bold text-white"
        >
          ✓
        </motion.div>
        <p className="text-white text-sm font-semibold mt-2">{percentage}%</p>
        <p className="text-white text-xs font-medium">{level}</p>
      </div>
    </motion.div>
  );
}
