import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function ScanChart({ scan, scanName }) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return <div className="text-slate-400">Loading scan data...</div>;
  }

  // Determine risk level and styling based on risk score
  const getRiskLevel = (score) => {
    if (score >= 70) return { level: "Critical", color: "text-red-400", bg: "bg-red-500/20", border: "border-red-500/50", icon: "🔴" };
    if (score >= 50) return { level: "High", color: "text-orange-400", bg: "bg-orange-500/20", border: "border-orange-500/50", icon: "🟠" };
    if (score >= 30) return { level: "Medium", color: "text-yellow-400", bg: "bg-yellow-500/20", border: "border-yellow-500/50", icon: "🟡" };
    return { level: "Low", color: "text-green-400", bg: "bg-green-500/20", border: "border-green-500/50", icon: "🟢" };
  };

  // Demo data if no scan provided
  const demoData = {
    title: scanName,
    riskScore: Math.floor(Math.random() * 100),
    openPorts: Math.floor(Math.random() * 20),
    timestamp: new Date().toLocaleTimeString(),
  };

  const data = scan || demoData;
  const riskInfo = getRiskLevel(data.riskScore);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-full flex flex-col"
    >
      {/* Header */}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-white mb-1">{data.title || "Security Scan"}</h3>
        <p className="text-xs text-slate-400">Last updated: {new Date(data.timestamp).toLocaleTimeString()}</p>
      </div>

      {/* Main Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 flex-1">
        {/* Risk Score Card */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className={`${riskInfo.bg} ${riskInfo.border} border rounded-xl p-4 backdrop-blur-sm`}
        >
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <span className="text-3xl">{riskInfo.icon}</span>
            </div>
            <p className="text-xs text-slate-400 mb-1">Risk Score</p>
            <p className={`text-3xl font-bold ${riskInfo.color}`}>{data.riskScore}%</p>
            <p className={`text-xs ${riskInfo.color} mt-1`}>{riskInfo.level}</p>
          </div>
        </motion.div>

        {/* Open Ports Card */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-blue-500/20 border border-blue-500/50 rounded-xl p-4 backdrop-blur-sm"
        >
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <span className="text-3xl">🔓</span>
            </div>
            <p className="text-xs text-slate-400 mb-1">Open Ports</p>
            <p className="text-3xl font-bold text-blue-300">{data.openPorts}</p>
            <p className="text-xs text-blue-300 mt-1">Services</p>
          </div>
        </motion.div>
      </div>

      {/* Risk Gauge/Progress Bar */}
      <div className="mt-6 pt-4 border-t border-slate-700">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-400 font-semibold">Risk Assessment</span>
          <span className={`text-xs font-bold ${riskInfo.color}`}>{riskInfo.level}</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${data.riskScore}%` }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className={`h-full ${
              data.riskScore >= 70
                ? "bg-gradient-to-r from-red-500 to-red-400"
                : data.riskScore >= 50
                ? "bg-gradient-to-r from-orange-500 to-orange-400"
                : data.riskScore >= 30
                ? "bg-gradient-to-r from-yellow-500 to-yellow-400"
                : "bg-gradient-to-r from-green-500 to-green-400"
            }`}
          />
        </div>
      </div>

      {/* Insights */}
      <div className="mt-4 p-3 bg-slate-800/50 rounded-lg border border-slate-600/50">
        <p className="text-xs text-slate-300 leading-relaxed">
          {data.riskScore >= 70
            ? "⚠️ Critical vulnerabilities detected. Immediate action required to secure your systems."
            : data.riskScore >= 50
            ? "⚠️ Significant security concerns found. Review exposed ports and strengthen firewall rules."
            : data.riskScore >= 30
            ? "ℹ️ Some security issues present. Monitor closely and apply recommended hardening measures."
            : "✅ System is secure. Continue regular scanning and maintain security best practices."}
        </p>
      </div>
    </motion.div>
  );
}
