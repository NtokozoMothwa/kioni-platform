import React from "react";
import { motion } from "framer-motion";
import { generateCSV, generatePDF } from "../utils/reportGenerator";

export default function ScanCard({ title, status, riskScore }) {
  const statusColor = status === "Safe" ? "text-green-400" : status === "Warning" ? "text-yellow-400" : "text-red-400";
  const statusBg = status === "Safe" ? "bg-green-500/10" : status === "Warning" ? "bg-yellow-500/10" : "bg-red-500/10";
  const scanData = { title, status, riskScore };

  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      whileTap={{ scale: 0.98 }}
      className="group bg-gradient-to-br from-slate-800 via-slate-900 to-slate-900 p-6 rounded-2xl border border-slate-700 hover:border-blue-500/50 transition-all duration-300 backdrop-blur-xl hover:shadow-2xl hover:shadow-blue-500/20"
    >
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-xl font-bold text-white">{title}</h2>
        <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusBg} ${statusColor}`}>
          {status}
        </span>
      </div>
      
      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between">
          <span className="text-slate-400 text-sm">Risk Score</span>
          <span className="text-2xl font-bold text-transparent bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text">
            {riskScore}%
          </span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${riskScore}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="h-full bg-gradient-to-r from-orange-400 to-red-500"
          />
        </div>
      </div>

      <div className="flex gap-2 mt-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => generateCSV(scanData)}
          className="flex-1 px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-md font-medium text-sm transition-colors"
        >
          📊 CSV
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => generatePDF(scanData)}
          className="flex-1 px-3 py-2 bg-green-500 hover:bg-green-600 text-white rounded-md font-medium text-sm transition-colors"
        >
          📄 PDF
        </motion.button>
      </div>
    </motion.div>
  );
}
