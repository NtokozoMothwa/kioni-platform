import Link from "next/link";
import { motion } from "framer-motion";
import { useRouter } from "next/router";

export default function Navbar() {
  const router = useRouter();
  const navItems = [
    { label: "Dashboard", href: "/" },
    { label: "Scan", href: "/scan" },
    { label: "Reports", href: "/reports" },
    { label: "Settings", href: "/settings" },
  ];

  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect bg-kioni-indigo-light border-kioni-cyan/30 p-4 flex justify-center gap-2 rounded-xl mb-6"
    >
      {navItems.map((item, idx) => {
        const isActive = router.pathname === item.href;
        return (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link
              href={item.href}
              className={`relative px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                isActive
                  ? "text-kioni-cyan bg-kioni-cyan/20 border border-kioni-cyan/50 neon-pulse"
                  : "text-slate-300 hover:text-kioni-cyan hover:bg-kioni-cyan/10"
              }`}
            >
              {item.label}
              {isActive && (
                <motion.div
                  layoutId="underline"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-kioni-cyan to-kioni-gold"
                />
              )}
            </Link>
          </motion.div>
        );
      })}
    </motion.nav>
  );
}
