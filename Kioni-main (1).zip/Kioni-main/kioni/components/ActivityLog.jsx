import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function ActivityLog({ activities = [] }) {
  const [defaultActivities, setDefaultActivities] = useState([]);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    setDefaultActivities([
      { id: 1, action: "Dashboard accessed", timestamp: new Date(Date.now() - 5000).toLocaleTimeString(), type: "info" },
      { id: 2, action: "System health check passed", timestamp: new Date(Date.now() - 60000).toLocaleTimeString(), type: "success" },
      { id: 3, action: "Compliance verified", timestamp: new Date(Date.now() - 120000).toLocaleTimeString(), type: "success" },
    ]);
  }, []);

  const logs = activities.length > 0 ? activities : defaultActivities;

  const getTypeColor = (type) => {
    switch (type) {
      case "success": return "border-l-4 border-green-500 bg-green-500 bg-opacity-10";
      case "warning": return "border-l-4 border-yellow-500 bg-yellow-500 bg-opacity-10";
      case "error": return "border-l-4 border-red-500 bg-red-500 bg-opacity-10";
      default: return "border-l-4 border-blue-500 bg-blue-500 bg-opacity-10";
    }
  };

  if (!isClient) {
    return <div className="bg-slate-800 bg-opacity-50 backdrop-blur-md p-6 rounded-xl border border-blue-500 border-opacity-20">
      <h3 className="text-lg font-bold mb-4 text-blue-300">Activity Log</h3>
      <p className="text-gray-400">Loading activity...</p>
    </div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800 bg-opacity-50 backdrop-blur-md p-6 rounded-xl border border-blue-500 border-opacity-20"
    >
      <h3 className="text-lg font-bold mb-4 text-blue-300">Activity Log</h3>
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {logs.map((log, idx) => (
          <motion.div
            key={log.id || idx}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`p-3 rounded ${getTypeColor(log.type)} text-sm`}
          >
            <div className="flex justify-between">
              <span className="text-white font-medium">{log.action}</span>
              <span className="text-gray-400 text-xs">{log.timestamp}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
