import React from "react";
import { motion } from "framer-motion";
import Navbar from "./Navbar";

export default function DashboardLayout({ children }) {
  return (
    <div className="min-h-screen bg-kioni-indigo text-white p-4 relative overflow-hidden">
      {/* Brand-aligned background elements with cyan and gold accents */}
      <motion.div
        className="absolute top-0 right-0 w-96 h-96 bg-kioni-cyan rounded-full mix-blend-multiply filter blur-3xl opacity-15"
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-0 left-0 w-96 h-96 bg-kioni-cyan rounded-full mix-blend-multiply filter blur-3xl opacity-10"
        animate={{ y: [0, 20, 0] }}
        transition={{ duration: 10, repeat: Infinity, delay: 1 }}
      />
      <motion.div
        className="absolute top-1/2 right-1/4 w-72 h-72 bg-kioni-gold rounded-full mix-blend-multiply filter blur-3xl opacity-5"
        animate={{ scale: [0.8, 1.2, 0.8] }}
        transition={{ duration: 15, repeat: Infinity }}
      />

      <div className="relative z-10">
        <header className="mb-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <motion.h1 
              className="text-6xl font-black text-center tracking-tight"
              animate={{ textShadow: ['0 0 10px rgba(0, 229, 255, 0.3)', '0 0 20px rgba(0, 229, 255, 0.6)', '0 0 10px rgba(0, 229, 255, 0.3)'] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <span className="bg-gradient-to-r from-kioni-cyan via-kioni-gold to-kioni-cyan bg-clip-text text-transparent">
                KIONI
              </span>
            </motion.h1>
          </motion.div>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-center text-white mt-2 text-lg font-medium tracking-wide"
          >
            Intelligence for a Safer, Smarter Africa
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1 }}
            className="flex justify-center mt-3 gap-2"
          >
            <motion.div 
              className="px-3 py-1 rounded-full glass-effect-cyan text-kioni-cyan text-xs font-semibold"
              whileHover={{ scale: 1.05 }}
            >
              🧠 Contextual Intelligence
            </motion.div>
            <motion.div 
              className="px-3 py-1 rounded-full glass-effect-gold text-kioni-gold text-xs font-semibold"
              whileHover={{ scale: 1.05 }}
            >
              ⚡ Automation Enabled
            </motion.div>
          </motion.div>
        </header>
        <Navbar />
        <main>{children}</main>
      </div>
    </div>
  );
}
