import DashboardLayout from "../components/DashboardLayout";
import ScanChart from "../components/ScanChart";
import RemediationCard from "../components/RemediationCard";
import TrustBadge from "../components/TrustBadge";
import SecurityStatus from "../components/SecurityStatus";
import VerificationIndicator from "../components/VerificationIndicator";
import ActivityLog from "../components/ActivityLog";
import SEOHead from "../components/SEOHead";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { useToast } from "../context/ToastContext";

export default function Home() {
  const [latestScans, setLatestScans] = useState([]);
  const { addToast } = useToast();

  useEffect(() => {
    // Fetch latest scans from database
    const fetchScans = async () => {
      try {
        const response = await fetch("/api/scans");
        if (response.ok) {
          const data = await response.json();
          setLatestScans(data.slice(0, 10)); // Show latest 10
        } else {
          throw new Error("Failed to fetch from database");
        }
      } catch (err) {
        console.warn("Failed to fetch from database, using localStorage:", err);
        // Fallback to localStorage
        if (typeof window !== "undefined") {
          const stored = localStorage.getItem("latestScans");
          if (stored) {
            try {
              setLatestScans(JSON.parse(stored));
            } catch (e) {
              console.error("Failed to parse scans from localStorage", e);
            }
          }
        }
      }
    };

    fetchScans();
  }, []);

  // Generate dynamic AI suggestions based on scan risk scores
  const aiIssues = latestScans.length > 0 
    ? latestScans.map((scan) => ({
        issue: `${scan.title} - Security Assessment`,
        suggestion: scan.riskScore > 50 
          ? `⚠️ High Risk: Close unused ports (${scan.openPorts} detected), enable firewall, review access policies` 
          : `✅ System Safe: Current risk level manageable. Continue monitoring (${scan.openPorts} ports open)`,
        severity: scan.riskScore > 70 ? "High" : scan.riskScore > 40 ? "Medium" : "Low"
      }))
    : [
        { issue: "Open Ports Detected", suggestion: "Close unused ports and enable firewall", severity: "High" },
        { issue: "Outdated SSL", suggestion: "Renew SSL certificate", severity: "Medium" },
        { issue: "Weak Password Policy", suggestion: "Enforce strong password rules", severity: "Low" },
      ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "KIONI",
    "description": "Africa's most advanced Contextual Intelligence & Operations Automation Platform. Real-time security intelligence and automated threat response.",
    "url": "https://kioni-security.com",
    "applicationCategory": "SecurityApplication",
    "offers": {
      "@type": "Offer",
      "priceCurrency": "USD",
      "price": "0"
    }
  };

  return (
    <>
      <SEOHead
        title="Dashboard - KIONI | Contextual Intelligence Platform"
        description="Real-time contextual intelligence and automated threat response. Monitor security posture with AI-powered insights designed for African enterprises."
        structuredData={structuredData}
        url="https://kioni-security.com"
      />
      <DashboardLayout>
      {/* Trust Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="mb-8"
      >
        <motion.div variants={itemVariants} className="mb-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-1">Your Security Intelligence Center</h2>
          <p className="text-slate-300 text-base">Monitor your operations in real-time with automated threat detection and intelligent insights</p>
        </motion.div>

        <motion.div variants={itemVariants} className="flex justify-center mb-8">
          <TrustBadge level="High" percentage={94} />
        </motion.div>

        <motion.div variants={itemVariants} className="mb-6">
          <SecurityStatus status="Protected" issues={0} />
        </motion.div>

        <motion.div
          variants={itemVariants}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group glass-effect-cyan bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl hover:neon-pulse transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-kioni-cyan font-semibold text-sm uppercase tracking-wide">System Health</h3>
              <span className="text-2xl">🧠</span>
            </div>
            <p className="text-4xl font-bold text-white mb-2">98%</p>
            <p className="text-slate-300 text-sm">Everything is running smoothly</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group glass-effect bg-kioni-indigo-light border-kioni-green/50 p-6 rounded-2xl transition-all duration-300 hover:border-kioni-green hover:shadow-lg hover:shadow-kioni-green/20"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-kioni-green font-semibold text-sm uppercase tracking-wide">Security Status</h3>
              <span className="text-2xl">🛡️</span>
            </div>
            <p className="text-4xl font-bold text-white mb-2">Protected</p>
            <p className="text-slate-300 text-sm">Your systems are secure and compliant</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group glass-effect-gold bg-kioni-indigo-light border-kioni-gold/50 p-6 rounded-2xl transition-all duration-300 hover:border-kioni-gold hover:shadow-lg hover:shadow-kioni-gold/20"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-kioni-gold font-semibold text-sm uppercase tracking-wide">Latest Assessment</h3>
              <span className="text-2xl">🔍</span>
            </div>
            {latestScans.length > 0 ? (
              <>
                <p className="text-4xl font-bold text-white mb-2">
                  {Math.floor((Date.now() - new Date(latestScans[0].timestamp).getTime()) / 60000)}m ago
                </p>
                <p className="text-slate-300 text-sm truncate">{latestScans[0].title}</p>
              </>
            ) : (
              <>
                <p className="text-4xl font-bold text-white mb-2">Ready</p>
                <p className="text-slate-300 text-sm">Run your first assessment</p>
              </>
            )}
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Charts & Activity Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="mb-8"
      >
        <motion.div variants={itemVariants} className="mb-6">
          <h2 className="text-3xl font-bold text-white mb-1">Recent Findings</h2>
          <p className="text-slate-300 text-base">Latest scan results and recommendations to keep you protected</p>
        </motion.div>
        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="glass-effect-cyan bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl hover:border-kioni-cyan transition-all duration-300">
            <ScanChart scan={latestScans[0]} scanName={latestScans[0]?.title || "Website Risk Score"} />
          </div>
          <div className="glass-effect-gold bg-kioni-indigo-light border-kioni-gold/50 p-6 rounded-2xl hover:border-kioni-gold transition-all duration-300">
            <ScanChart scan={latestScans[1]} scanName={latestScans[1]?.title || "Server Risk Score"} />
          </div>
        </motion.div>
        <motion.div variants={itemVariants}>
          <ActivityLog />
        </motion.div>
      </motion.div>

      {/* Remediations Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="mb-6">
          <h2 className="text-3xl font-bold text-white mb-1">What You Should Do</h2>
          <p className="text-slate-300 text-base">Actionable recommendations to strengthen your security posture</p>
        </motion.div>
        <motion.div variants={itemVariants} className="space-y-4">
          {aiIssues.map((issue, idx) => (
            <RemediationCard
              key={idx}
              issue={issue.issue}
              suggestion={issue.suggestion}
              severity={issue.severity}
            />
          ))}
        </motion.div>
      </motion.div>
    </DashboardLayout>
    </>
  );
}
