import { useAuth } from '../../context/AuthContext';
import { useEffect, useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import { motion } from 'framer-motion';
import SEOHead from '../../components/SEOHead';

export default function AdminAuditLogs() {
  const { token } = useAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await fetch('/api/admin/audit-logs?limit=500', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setLogs(data.logs.reverse());
        }
      } catch (err) {
        console.error('Failed to load logs:', err);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchLogs();
  }, [token]);

  const filteredLogs = logs.filter((log) => {
    if (filter === 'all') return true;
    if (filter === 'auth') return log.includes('AUTH') || log.includes('LOGIN') || log.includes('REGISTERED');
    if (filter === 'scan') return log.includes('SCAN');
    if (filter === 'admin') return log.includes('ADMIN');
    if (filter === 'error') return log.includes('ERROR') || log.includes('FAILED');
    return true;
  });

  const getLogColor = (log) => {
    if (log.includes('ERROR') || log.includes('FAILED')) return 'text-red-400';
    if (log.includes('WARNING')) return 'text-yellow-400';
    if (log.includes('ADMIN')) return 'text-kioni-gold';
    if (log.includes('AUTH') || log.includes('LOGIN')) return 'text-kioni-cyan';
    return 'text-slate-300';
  };

  if (loading) {
    return (
      <AdminLayout>
        <p className="text-kioni-cyan">Loading logs...</p>
      </AdminLayout>
    );
  }

  return (
    <>
      <SEOHead title="Audit Logs - KIONI Admin" />
      <AdminLayout>
        <div>
          <h2 className="text-3xl font-bold text-white mb-8">System Audit Logs</h2>

          {/* Filter Buttons */}
          <div className="flex gap-2 mb-6 flex-wrap">
            {['all', 'auth', 'scan', 'admin', 'error'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                  filter === f
                    ? 'bg-kioni-cyan text-kioni-indigo'
                    : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>

          {/* Logs Display */}
          <div className="glass-effect bg-kioni-indigo-light border-kioni-cyan/50 rounded-xl p-6 max-h-96 overflow-y-auto">
            {filteredLogs.length > 0 ? (
              <div className="space-y-2 font-mono text-sm">
                {filteredLogs.map((log, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`p-2 rounded border-l-2 border-slate-600 ${getLogColor(log)} break-all`}
                  >
                    {log}
                  </motion.div>
                ))}
              </div>
            ) : (
              <p className="text-slate-400 text-center py-8">No logs found for this filter</p>
            )}
          </div>

          <p className="text-slate-500 text-sm mt-4">
            Showing {filteredLogs.length} of {logs.length} log entries
          </p>
        </div>
      </AdminLayout>
    </>
  );
}
