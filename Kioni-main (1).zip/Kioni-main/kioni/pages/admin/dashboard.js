import { useAuth } from '../../context/AuthContext';
import { useEffect, useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import { motion } from 'framer-motion';
import SEOHead from '../../components/SEOHead';

export default function AdminDashboard() {
  const { user, token } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalScans: 0,
    recentLogs: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const usersRes = await fetch('/api/admin/users', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        const users = usersRes.ok ? await usersRes.json() : [];

        setStats({
          totalUsers: users.length,
          totalScans: users.reduce((sum, u) => sum + (u.scans || 0), 0),
          recentLogs: [],
        });
      } catch (err) {
        console.error('Failed to fetch stats:', err);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchStats();
  }, [token]);

  const StatCard = ({ icon, label, value }) => (
    <motion.div
      whileHover={{ y: -5 }}
      className="glass-effect bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-xl"
    >
      <div className="text-3xl mb-2">{icon}</div>
      <p className="text-slate-400 text-sm mb-2">{label}</p>
      <p className="text-3xl font-bold text-kioni-cyan">{value}</p>
    </motion.div>
  );

  if (loading) {
    return (
      <AdminLayout>
        <p className="text-kioni-cyan">Loading...</p>
      </AdminLayout>
    );
  }

  return (
    <>
      <SEOHead title="Admin Dashboard - KIONI" />
      <AdminLayout>
        <div>
          <h2 className="text-3xl font-bold text-white mb-8">Admin Dashboard</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <StatCard icon="👥" label="Total Users" value={stats.totalUsers} />
            <StatCard icon="🔍" label="Total Scans" value={stats.totalScans} />
            <StatCard icon="✓" label="Status" value="Operational" />
          </div>

          <div className="glass-effect bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-xl">
            <h3 className="text-xl font-bold text-white mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button className="p-4 bg-slate-800/50 hover:bg-slate-700 rounded-lg text-left text-slate-300 hover:text-kioni-cyan transition">
                <p className="font-semibold">Manage Users</p>
                <p className="text-sm text-slate-500">Edit roles, deactivate accounts</p>
              </button>
              <button className="p-4 bg-slate-800/50 hover:bg-slate-700 rounded-lg text-left text-slate-300 hover:text-kioni-cyan transition">
                <p className="font-semibold">View Audit Logs</p>
                <p className="text-sm text-slate-500">Security events and activities</p>
              </button>
            </div>
          </div>
        </div>
      </AdminLayout>
    </>
  );
}
