import { useAuth } from '../../context/AuthContext';
import { useEffect, useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import { motion } from 'framer-motion';
import SEOHead from '../../components/SEOHead';

export default function AdminUsers() {
  const { user, token } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/admin/users', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (res.ok) {
          setUsers(await res.json());
        }
      } catch (err) {
        setError('Failed to load users');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchUsers();
  }, [token]);

  const toggleAdmin = async (userId, currentAdmin) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ is_admin: !currentAdmin }),
      });

      if (res.ok) {
        setUsers(users.map(u => u.id === userId ? { ...u, is_admin: !currentAdmin } : u));
      }
    } catch (err) {
      console.error('Failed to update user:', err);
    }
  };

  const deleteUser = async (userId, username) => {
    if (!confirm(`Delete user ${username}? This cannot be undone.`)) return;

    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (res.ok) {
        setUsers(users.filter(u => u.id !== userId));
      }
    } catch (err) {
      console.error('Failed to delete user:', err);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <p className="text-kioni-cyan">Loading users...</p>
      </AdminLayout>
    );
  }

  return (
    <>
      <SEOHead title="User Management - KIONI Admin" />
      <AdminLayout>
        <div>
          <h2 className="text-3xl font-bold text-white mb-8">User Management</h2>

          {error && (
            <div className="mb-4 p-4 bg-red-500/20 border border-red-500 rounded-lg text-red-300">
              {error}
            </div>
          )}

          <div className="glass-effect bg-kioni-indigo-light border-kioni-cyan/50 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-kioni-cyan/30 bg-slate-800/50">
                    <th className="px-6 py-4 text-left text-kioni-cyan font-semibold">Username</th>
                    <th className="px-6 py-4 text-left text-kioni-cyan font-semibold">Email</th>
                    <th className="px-6 py-4 text-left text-kioni-cyan font-semibold">Role</th>
                    <th className="px-6 py-4 text-left text-kioni-cyan font-semibold">Joined</th>
                    <th className="px-6 py-4 text-left text-kioni-cyan font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <motion.tr
                      key={u.id}
                      whileHover={{ backgroundColor: 'rgba(0,229,255,0.05)' }}
                      className="border-b border-slate-700/50"
                    >
                      <td className="px-6 py-4 text-white font-semibold">{u.username}</td>
                      <td className="px-6 py-4 text-slate-300">{u.email}</td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            u.is_admin
                              ? 'bg-kioni-gold/20 text-kioni-gold'
                              : 'bg-slate-600/50 text-slate-300'
                          }`}
                        >
                          {u.is_admin ? 'Admin' : 'User'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-400">
                        {new Date(u.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 flex gap-2">
                        {u.id !== user.id && (
                          <>
                            <button
                              onClick={() => toggleAdmin(u.id, u.is_admin)}
                              className="px-3 py-1 bg-kioni-cyan/20 text-kioni-cyan hover:bg-kioni-cyan/30 rounded text-sm transition"
                            >
                              {u.is_admin ? 'Demote' : 'Promote'}
                            </button>
                            <button
                              onClick={() => deleteUser(u.id, u.username)}
                              className="px-3 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-sm transition"
                            >
                              Delete
                            </button>
                          </>
                        )}
                        {u.id === user.id && (
                          <span className="text-slate-500 text-sm italic">You</span>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>

            {users.length === 0 && (
              <div className="px-6 py-12 text-center text-slate-400">
                <p>No users found</p>
              </div>
            )}
          </div>
        </div>
      </AdminLayout>
    </>
  );
}
