import DashboardLayout from "../components/DashboardLayout";
import SEOHead from "../components/SEOHead";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { useToast } from "../context/ToastContext";

export default function Settings() {
  const [settings, setSettings] = useState({
    notifications: true,
    emailAlerts: false,
    autoScan: false,
    scanInterval: 24,
  });
  const [isClient, setIsClient] = useState(false);
  const { addToast } = useToast();

  useEffect(() => {
    setIsClient(true);
    // Load saved settings
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("appSettings");
      if (saved) {
        try {
          setSettings(JSON.parse(saved));
        } catch (e) {
          console.error("Failed to load settings", e);
        }
      }
    }
  }, []);

  const handleSettingChange = (key, value) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    // Save to localStorage
    if (typeof window !== "undefined") {
      localStorage.setItem("appSettings", JSON.stringify(updated));
    }
    addToast("Setting saved", "success");
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Kioni V2 Settings",
    "description": "Manage your account settings, notifications, and scanning preferences"
  };

  return (
    <>
      <SEOHead
        title="Settings & Preferences - KIONI"
        description="Configure automation workflows, intelligence assessment settings, and API access for your KIONI contextual intelligence platform."
        structuredData={structuredData}
        url="https://kioni-security.com/settings"
      />
      <DashboardLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-2xl mx-auto"
      >
        <motion.div variants={itemVariants} className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Settings</h2>
          <p className="text-slate-300 text-base">Personalize your experience and choose how you want to be notified about important security updates</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Plan Card */}
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="group glass-effect-gold bg-kioni-indigo-light border-kioni-gold/50 p-6 rounded-2xl hover:border-kioni-gold transition-all duration-300"
          >
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">💎</span>
              <h3 className="text-lg font-semibold text-white">Subscription Plan</h3>
            </div>
            <p className="text-slate-300 mb-3 font-medium">You're on the <span className="text-kioni-gold">Professional Plan</span></p>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">Advanced threat detection, unlimited scans, and priority support</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full btn-primary"
            >
              Upgrade to Pro
            </motion.button>
          </motion.div>

          {/* Notifications Card */}
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="group glass-effect-cyan bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl hover:border-kioni-cyan transition-all duration-300"
          >
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">🔔</span>
              <h3 className="text-lg font-semibold text-white">Notifications</h3>
            </div>
            {isClient && (
              <>
                <div className="space-y-3 mb-6">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.notifications}
                      onChange={(e) => handleSettingChange("notifications", e.target.checked)}
                      className="w-4 h-4 rounded"
                    />
                    <span className="text-sm text-slate-300">Notify me of security alerts</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.emailAlerts}
                      onChange={(e) => handleSettingChange("emailAlerts", e.target.checked)}
                      className="w-4 h-4 rounded"
                    />
                    <span className="text-sm text-slate-300">Send me email notifications</span>
                  </label>
                </div>
                <p className="text-sm text-slate-400">
                  {settings.notifications && settings.emailAlerts ? "All notifications enabled" : "Some notifications disabled"}
                </p>
              </>
            )}
          </motion.div>

          {/* Auto Scan Card */}
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="group glass-effect bg-kioni-indigo-light border-kioni-green/50 p-6 rounded-2xl hover:border-kioni-green transition-all duration-300"
          >
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">⚡</span>
              <h3 className="text-lg font-semibold text-white">Intelligence Automation</h3>
            </div>
            {isClient && (
              <>
                <label className="flex items-center gap-3 cursor-pointer mb-4">
                  <input
                    type="checkbox"
                    checked={settings.autoScan}
                    onChange={(e) => handleSettingChange("autoScan", e.target.checked)}
                    className="w-4 h-4 rounded"
                  />
                  <span className="text-sm text-slate-300">Automatically scan my systems</span>
                </label>
                {settings.autoScan && (
                  <div>
                    <label className="text-xs text-slate-300 mb-2 block">Check security every {settings.scanInterval} hours</label>
                    <input
                      type="range"
                      min="1"
                      max="168"
                      step="1"
                      value={settings.scanInterval}
                      onChange={(e) => handleSettingChange("scanInterval", parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                )}
              </>
            )}
          </motion.div>

          {/* API Keys Card */}
          <motion.div
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="group glass-effect-gold bg-kioni-indigo-light border-kioni-gold/50 p-6 rounded-2xl hover:border-kioni-gold transition-all duration-300"
          >
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">🔑</span>
              <h3 className="text-lg font-semibold text-white">API Keys</h3>
            </div>
            <p className="text-slate-300 mb-3 font-medium">Connect with your tools</p>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">Create API keys to integrate KIONI with your existing security tools</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full btn-secondary"
            >
              Manage Keys
            </motion.button>
          </motion.div>
        </div>
      </motion.div>
    </DashboardLayout>
    </>
  );
}
