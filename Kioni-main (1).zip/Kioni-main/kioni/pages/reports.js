import DashboardLayout from "../components/DashboardLayout";
import SEOHead from "../components/SEOHead";
import { motion } from "framer-motion";
import { useToast } from "../context/ToastContext";
import { generateSecurityReport, downloadPDF } from "../utils/pdfExport";
import { useState, useEffect } from "react";

const dummyReports = [
  { name: "Website Scan - 21 Nov 2025", riskScore: 12, type: "security" },
  { name: "Server Scan - 20 Nov 2025", riskScore: 45, type: "infrastructure" },
];

export default function Reports() {
  const [scans, setScans] = useState([]);
  const { addToast } = useToast();

  useEffect(() => {
    // Fetch scans from database
    const fetchScans = async () => {
      try {
        const response = await fetch("/api/scans");
        if (response.ok) {
          const data = await response.json();
          setScans(data);
        } else {
          // Fallback to localStorage
          if (typeof window !== "undefined") {
            const stored = localStorage.getItem("latestScans");
            if (stored) {
              setScans(JSON.parse(stored));
            }
          }
        }
      } catch (err) {
        console.warn("Failed to fetch from database, using localStorage:", err);
        // Fallback to localStorage
        if (typeof window !== "undefined") {
          const stored = localStorage.getItem("latestScans");
          if (stored) {
            try {
              setScans(JSON.parse(stored));
            } catch (e) {
              console.error("Failed to parse scans", e);
            }
          }
        }
      }
    };

    fetchScans();
  }, []);

  const handleDownloadReport = (scan) => {
    try {
      const doc = generateSecurityReport(scan, `Security Report - ${scan.title}`);
      downloadPDF(doc, `kioni-report-${scan.title.replace(/\./g, '-')}.pdf`);
      addToast(`✅ Report downloaded for ${scan.title}`, "success");
    } catch (error) {
      console.error("PDF generation error:", error);
      addToast("Failed to generate report", "error");
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    "name": "Security Reports",
    "description": "Comprehensive scan reports with security findings and historical data"
  };

  return (
    <>
      <SEOHead
        title="Intelligence Reports - KIONI"
        description="Comprehensive threat intelligence reports with contextual analysis, risk assessments, and automated remediation guidance."
        structuredData={structuredData}
        url="https://kioni-security.com/reports"
      />
      <DashboardLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-2xl mx-auto"
      >
        <motion.div variants={itemVariants} className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Security Reports</h2>
          <p className="text-slate-300 text-base">View all your past scans and security assessments in one place</p>
        </motion.div>

        <div className="space-y-4">
          {scans.length > 0 ? (
            scans.map((scan, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ scale: 1.02, y: -3 }}
              className="group glass-effect bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl hover:border-kioni-cyan transition-all duration-300 flex justify-between items-center"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-kioni-cyan/20 rounded-xl">
                  <span className="text-xl">🔍</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white">{scan.title}</h3>
                  <p className="text-sm text-slate-300 mt-1">
                    <span className="inline-block bg-slate-700/50 px-2 py-1 rounded text-xs">
                      {new Date(scan.timestamp).toLocaleDateString()}
                    </span>
                    <span className="ml-2 text-kioni-cyan font-medium">Risk: {scan.riskScore}%</span>
                  </p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleDownloadReport(scan)}
                className="px-4 py-2 bg-gradient-to-r from-kioni-cyan to-kioni-gold text-kioni-indigo font-semibold rounded-lg hover:shadow-lg hover:shadow-kioni-cyan/50 transition-all text-sm"
              >
                📥 Download
              </motion.button>
            </motion.div>
            ))
          ) : (
            <motion.div
              variants={itemVariants}
              className="text-center py-12 glass-effect bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl"
            >
              <p className="text-slate-300 text-lg mb-2">No scans yet</p>
              <p className="text-slate-400">Run your first threat assessment to generate reports</p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </DashboardLayout>
    </>
  );
}
