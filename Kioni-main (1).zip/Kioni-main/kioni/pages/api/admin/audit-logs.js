export default async function handler(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const limit = req.query.limit || 100;

  if (!token) {
    return res.status(401).json({ error: 'Missing token' });
  }

  try {
    const response = await fetch(`http://localhost:6000/admin/audit-logs?limit=${limit}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: 'Failed to fetch logs' });
    }

    const data = await response.json();
    return res.status(200).json(data);
  } catch (error) {
    console.error('Admin audit logs error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
