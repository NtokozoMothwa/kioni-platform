export default async function handler(req, res) {
  const { id } = req.query;
  const { method } = req;
  const apiKey = process.env.API_KEY;

  if (method === "GET") {
    try {
      const response = await fetch(`http://localhost:6000/api/scans/${id}`, {
        method: "GET",
        headers: {
          "X-API-KEY": apiKey || "dev-key",
        },
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: "Scan not found" });
      }

      const scan = await response.json();
      res.status(200).json(scan);
    } catch (error) {
      console.error("Error fetching scan:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  } else if (method === "PUT") {
    try {
      const response = await fetch(`http://localhost:6000/api/scans/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": apiKey || "dev-key",
        },
        body: JSON.stringify(req.body),
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to update scan" });
      }

      const scan = await response.json();
      res.status(200).json(scan);
    } catch (error) {
      console.error("Error updating scan:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  } else if (method === "DELETE") {
    try {
      const response = await fetch(`http://localhost:6000/api/scans/${id}`, {
        method: "DELETE",
        headers: {
          "X-API-KEY": apiKey || "dev-key",
        },
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to delete scan" });
      }

      res.status(204).end();
    } catch (error) {
      console.error("Error deleting scan:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  } else {
    res.status(405).json({ error: "Method not allowed" });
  }
}
