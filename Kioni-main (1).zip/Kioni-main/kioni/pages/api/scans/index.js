export default async function handler(req, res) {
  const { method } = req;
  const apiKey = process.env.API_KEY;

  if (method === "GET") {
    // Retrieve all scans from database
    try {
      const response = await fetch("http://localhost:6000/api/scans", {
        method: "GET",
        headers: {
          "X-API-KEY": apiKey || "dev-key",
        },
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to fetch scans" });
      }

      const scans = await response.json();
      res.status(200).json(scans);
    } catch (error) {
      console.error("Error fetching scans:", error);
      res.status(200).json([]); // Return empty array as fallback
    }
  } else if (method === "POST") {
    // Create a new scan
    try {
      const { title, target, riskScore, status, openPorts, vulnerabilities } = req.body;

      const response = await fetch("http://localhost:6000/api/scans", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": apiKey || "dev-key",
        },
        body: JSON.stringify({
          title,
          target,
          risk_score: riskScore,
          status,
          open_ports: openPorts,
          vulnerabilities,
        }),
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to create scan" });
      }

      const scan = await response.json();
      res.status(201).json(scan);
    } catch (error) {
      console.error("Error creating scan:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  } else {
    res.status(405).json({ error: "Method not allowed" });
  }
}
