// API route that bridges frontend to scanner service
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { target } = req.body;

  if (!target) {
    return res.status(400).json({ error: 'Target IP or domain required' });
  }

  try {
    // Call internal Flask scanner service
    const scanResponse = await fetch('http://127.0.0.1:6000/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target }),
    });

    if (!scanResponse.ok) {
      const error = await scanResponse.json();
      return res.status(scanResponse.status).json(error);
    }

    const scanData = await scanResponse.json();
    
    // Log scan activity
    console.log(`[SCAN] Target: ${target}, Risk Score: ${scanData.risk_score}, Time: ${new Date().toISOString()}`);

    return res.status(200).json({
      success: true,
      target,
      riskScore: scanData.risk_score,
      openPorts: scanData.open_ports,
      details: scanData.details || [],
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error(`[SCAN ERROR] ${error.message}`);
    return res.status(500).json({
      error: 'Scan failed',
      message: error.message,
    });
  }
}
