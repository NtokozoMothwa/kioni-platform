// Health check endpoint for monitoring
export default function handler(req, res) {
  return res.status(200).json({
    status: "ok",
    service: "Kioni V2 Frontend",
    timestamp: new Date().toISOString(),
  });
}
