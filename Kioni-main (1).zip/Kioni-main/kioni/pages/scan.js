import DashboardLayout from "../components/DashboardLayout";
import SEOHead from "../components/SEOHead";
import { useState } from "react";
import { motion } from "framer-motion";
import { useToast } from "../context/ToastContext";
import { copyToClipboard, formatScanData } from "../utils/clipboard";

export default function ScanPage() {
  const [target, setTarget] = useState("");
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { addToast } = useToast();

  const handleScan = async () => {
    if (!target.trim()) {
      setError("Please enter a target IP or domain");
      addToast("Target field cannot be empty", "error");
      return;
    }

    // Basic validation
    const urlPattern = /^([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$|^(\d{1,3}\.){3}\d{1,3}$/;
    if (!urlPattern.test(target.trim())) {
      setError("Invalid IP address or domain format");
      addToast("Invalid IP address or domain", "error");
      return;
    }

    setLoading(true);
    setError("");
    addToast("Starting security scan...", "info");

    try {
      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Scan failed");
      }

      // Save scan to database
      const dbResponse = await fetch("/api/scans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: target,
          target: target,
          riskScore: data.riskScore,
          status: "Complete",
          openPorts: data.openPorts,
          vulnerabilities: data.details || [],
        }),
      });

      if (!dbResponse.ok) {
        console.warn("Failed to save scan to database");
      }

      const newScan = {
        title: target,
        status: "Complete",
        riskScore: data.riskScore,
        openPorts: data.openPorts,
        timestamp: data.timestamp,
      };

      const updatedScans = [newScan, ...scans];
      setScans(updatedScans);

      // Also store in localStorage as fallback
      if (typeof window !== "undefined") {
        localStorage.setItem("latestScans", JSON.stringify(updatedScans));
      }

      setTarget("");
      addToast(`✅ Scan completed for ${target}`, "success");
    } catch (err) {
      const errorMsg = err.message || "An error occurred during the scan";
      setError(errorMsg);
      addToast(errorMsg, "error");
      console.error("Scan error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyScan = async (scan) => {
    const text = formatScanData(scan);
    const copied = await copyToClipboard(text);
    if (copied) {
      addToast("Scan data copied to clipboard", "success");
    } else {
      addToast("Failed to copy scan data", "error");
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !loading) {
      handleScan();
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Action",
    "name": "Threat Assessment",
    "description": "Contextual intelligence analysis for comprehensive threat detection and asset vulnerability assessment"
  };

  return (
    <>
      <SEOHead
        title="Threat Assessment - KIONI"
        description="Automated threat assessment and contextual analysis. Identify vulnerabilities with precision intelligence designed for enterprise operations."
        structuredData={structuredData}
        url="https://kioni-security.com/scan"
      />
      <DashboardLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-3xl mx-auto"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Run a Security Check</h2>
          <p className="text-slate-300 text-base">Scan your network or website to find vulnerabilities and threats. Just enter the address below.</p>
        </motion.div>

        {/* Input Section */}
        <motion.div
          variants={itemVariants}
          className="mb-8 glass-effect-cyan bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl"
        >
          <div className="mb-4">
            <label className="block text-sm font-semibold text-slate-200 mb-2 uppercase tracking-wide">
              What do you want to scan?
            </label>
            <input
              type="text"
              placeholder="Enter your website URL or IP address (e.g., example.com or 192.168.1.1)"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
              className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
            />
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-300 text-sm flex items-center gap-2"
            >
              <span className="text-xl">⚠️</span>
              <div>
                <strong>Hmm, something's not right:</strong> {error}
              </div>
            </motion.div>
          )}

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleScan}
            disabled={loading}
            className="w-full px-6 py-3 bg-gradient-to-r from-kioni-cyan to-kioni-gold text-kioni-indigo font-semibold rounded-lg hover:shadow-lg hover:shadow-kioni-cyan/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-kioni-indigo border-t-transparent rounded-full animate-spin" />
                Assessing...
              </span>
            ) : (
              "Start Assessment"
            )}
          </motion.button>
        </motion.div>

        {/* Results Section */}
        {scans.length > 0 && (
          <motion.div variants={itemVariants}>
            <h3 className="text-2xl font-bold text-white mb-4">Your Scan Results</h3>
            <p className="text-slate-300 mb-4">Here's what we found:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {scans.map((scan, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="group glass-effect bg-kioni-indigo-light border-kioni-cyan/50 p-6 rounded-2xl hover:border-kioni-cyan transition-all duration-300"
                >
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="text-lg font-bold text-white break-all">{scan.title}</h4>
                    <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-xs font-semibold whitespace-nowrap ml-2">
                      ✓ Complete
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-slate-400 text-sm">Open Ports</span>
                        <span className="font-bold text-cyan-300 text-lg">{scan.openPorts}</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-slate-400 text-sm">Risk Score</span>
                        <span className="font-bold text-transparent bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-lg">
                          {scan.riskScore}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${scan.riskScore}%` }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          className="h-full bg-gradient-to-r from-orange-400 to-red-500"
                        />
                      </div>
                    </div>

                    <div className="text-xs text-slate-400 pt-2 border-t border-slate-700">
                      {new Date(scan.timestamp).toLocaleString()}
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleCopyScan(scan)}
                      className="w-full mt-3 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-semibold rounded-lg transition-all"
                    >
                      📋 Copy Results
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Empty State */}
        {scans.length === 0 && !loading && (
          <motion.div
            variants={itemVariants}
            className="text-center py-16"
          >
            <div className="inline-block p-4 bg-blue-500/20 rounded-full mb-4">
              <span className="text-5xl">🔍</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No Scans Yet</h3>
            <p className="text-slate-400">Enter a target IP or domain above to perform your first security scan</p>
          </motion.div>
        )}
      </motion.div>
    </DashboardLayout>
    </>
  );
}
