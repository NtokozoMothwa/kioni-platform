console.log('Next.js server is running in the kioni directory');
console.log('Use the workflow "Run Application" to start the dev server');
