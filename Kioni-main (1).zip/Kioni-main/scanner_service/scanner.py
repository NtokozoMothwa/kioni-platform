#!/usr/bin/env python3
import os
import logging
import ipaddress
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import nmap
import jwt
from database import (
    get_all_scans, get_scan, create_scan, update_scan, delete_scan, add_scan_result,
    create_user, get_user_by_email, get_user_by_id, verify_password,
    get_all_users, update_user, delete_user
)
from auth import generate_token, verify_token, require_auth, require_admin  # noqa: F401

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scanner_service/scanner.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Audit logging for security events
audit_logger = logging.getLogger('audit')
audit_handler = logging.FileHandler('scanner_service/scan_audit.log')
audit_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
audit_logger.addHandler(audit_handler)
audit_logger.setLevel(logging.INFO)

# Initialize Flask app
app = Flask(__name__)

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["10 per hour", "2 per minute"],
    storage_uri="memory://"
)

# Security Configuration
API_KEY = os.environ.get('API_KEY')
JWT_SECRET = os.environ.get('JWT_SECRET', 'kioni-dev-secret-key')
ALLOWED_NETWORKS_STR = os.environ.get('ALLOWED_NETWORKS', '')

# Parse allowed networks
ALLOWED_NETWORKS = []
if ALLOWED_NETWORKS_STR:
    try:
        for network_str in ALLOWED_NETWORKS_STR.split(','):
            network_str = network_str.strip()
            if network_str:
                ALLOWED_NETWORKS.append(ipaddress.ip_network(network_str, strict=False))
        logger.info(f"Initialized with {len(ALLOWED_NETWORKS)} allowed networks")
    except ValueError as e:
        logger.error(f"Invalid ALLOWED_NETWORKS format: {e}")


def require_api_key(f):
    """Decorator to validate API key in request header"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-KEY')
        
        # Log all requests
        logger.info(f"Request from {request.remote_addr}: {request.method} {request.path}")
        
        # Validate API key
        if not api_key:
            audit_logger.warning(f"UNAUTHORIZED: No API key provided from {request.remote_addr}")
            return jsonify({"error": "Missing X-API-KEY header"}), 401
        
        if api_key != API_KEY:
            audit_logger.warning(f"UNAUTHORIZED: Invalid API key from {request.remote_addr}")
            return jsonify({"error": "Invalid API key"}), 401
        
        return f(*args, **kwargs)
    return decorated_function


def is_target_allowed(target):
    """Check if target is in allowed networks"""
    if not ALLOWED_NETWORKS:
        # If no networks configured, allow all (for development)
        logger.warning("No ALLOWED_NETWORKS configured - allowing all targets")
        return True
    
    try:
        target_ip = ipaddress.ip_address(target)
        for network in ALLOWED_NETWORKS:
            if target_ip in network:
                return True
        return False
    except ValueError:
        # Not a valid IP, might be a hostname - log and reject for security
        logger.warning(f"Invalid IP target format: {target}")
        return False


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint (no auth required)"""
    return jsonify({
        "status": "healthy",
        "service": "KIONI Scanner Service",
        "timestamp": datetime.utcnow().isoformat()
    }), 200


@app.route('/scan/quick', methods=['POST'])
@limiter.limit("2 per minute; 10 per hour")
@require_api_key
def quick_scan():
    """
    Quick threat assessment endpoint
    Requires: X-API-KEY header, target in ALLOWED_NETWORKS
    """
    try:
        # Get target from request
        data = request.get_json()
        if not data or not data.get('target'):
            audit_logger.warning(f"INVALID_REQUEST: No target provided from {request.remote_addr}")
            return jsonify({"error": "No target provided"}), 400
        
        target = data.get('target').strip()
        
        # Validate target format
        try:
            ipaddress.ip_address(target)
        except ValueError:
            audit_logger.warning(f"INVALID_TARGET: Invalid IP format '{target}' from {request.remote_addr}")
            return jsonify({"error": "Invalid target IP format"}), 400
        
        # Check if target is in allowed networks
        if not is_target_allowed(target):
            audit_logger.warning(f"UNAUTHORIZED_TARGET: Target '{target}' not in allowed networks from {request.remote_addr}")
            return jsonify({"error": "Target IP is not in allowed assessment scope"}), 403
        
        # Perform scan
        audit_logger.info(f"SCAN_INITIATED: Target '{target}' from {request.remote_addr}")
        logger.info(f"Starting nmap scan on target: {target}")
        
        try:
            nm = nmap.PortScanner()
            nm.scan(target, arguments="-sV -p 1-1024 --host-timeout 30s")
            
            # Calculate risk score based on open ports and services
            risk_data = []
            open_ports = 0
            
            if nm.all_hosts():
                for host in nm.all_hosts():
                    for proto in nm[host].all_protocols():
                        ports = nm[host][proto].keys()
                        for port in ports:
                            state = nm[host][proto][port]['state']
                            service = nm[host][proto][port].get('name', 'unknown')
                            if state == 'open':
                                open_ports += 1
                                risk_data.append({
                                    "port": port,
                                    "service": service,
                                    "state": state
                                })
            
            risk_score = min(open_ports * 15, 100)
            
            # Log successful scan
            audit_logger.info(f"SCAN_COMPLETED: Target '{target}' - {open_ports} open ports, risk score {risk_score}")
            
            return jsonify({
                "target": target,
                "open_ports": open_ports,
                "risk_score": risk_score,
                "details": risk_data,
                "timestamp": datetime.utcnow().isoformat()
            }), 200
        
        except nmap.nmap.PortScannerError as e:
            logger.error(f"Nmap scan error for {target}: {str(e)}")
            audit_logger.error(f"SCAN_ERROR: Target '{target}' - {str(e)}")
            return jsonify({"error": "Scan failed"}), 500
    
    except Exception as e:
        logger.error(f"Unexpected error in quick_scan: {str(e)}")
        audit_logger.error(f"CRITICAL_ERROR: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500


# Authentication Endpoints

@app.route('/auth/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.get_json()
        email = data.get('email')
        username = data.get('username')
        password = data.get('password')
        
        if not email or not username or not password:
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Check if user already exists
        if get_user_by_email(email):
            return jsonify({'error': 'Email already registered'}), 409
        
        user = create_user(email, username, password)
        if not user:
            return jsonify({'error': 'Registration failed'}), 500
        
        token = generate_token(user['id'])
        audit_logger.info(f"USER_REGISTERED: {username} ({email})")
        
        return jsonify({
            'token': token,
            'user': user
        }), 201
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        return jsonify({'error': 'Registration failed'}), 500

@app.route('/auth/login', methods=['POST'])
def login():
    """Login user"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': 'Missing email or password'}), 400
        
        user = verify_password(email, password)
        if not user:
            audit_logger.warning(f"LOGIN_FAILED: {email}")
            return jsonify({'error': 'Invalid credentials'}), 401
        
        token = generate_token(user['id'])
        audit_logger.info(f"USER_LOGIN: {user['username']}")
        
        return jsonify({
            'token': token,
            'user': user
        }), 200
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Login failed'}), 500

@app.route('/auth/verify', methods=['POST'])
@require_auth
def verify():
    """Verify token"""
    try:
        user = get_user_by_id(request.user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({
            'token': request.headers.get('Authorization').replace('Bearer ', ''),
            'user': user
        }), 200
    except Exception as e:
        logger.error(f"Token verify error: {str(e)}")
        return jsonify({'error': 'Verification failed'}), 500

# Database API Endpoints

@app.route('/api/scans', methods=['GET'])
@require_auth
def get_scans_api():
    """Retrieve all scans for authenticated user"""
    try:
        scans = get_all_scans(user_id=request.user_id)
        return jsonify(scans), 200
    except Exception as e:
        logger.error(f"Error retrieving scans: {str(e)}")
        return jsonify({"error": "Failed to retrieve scans"}), 500


@app.route('/api/scans', methods=['POST'])
@require_auth
def create_scan_api():
    """Create a new scan record for authenticated user"""
    try:
        data = request.get_json()
        title = data.get('title')
        target = data.get('target')
        risk_score = data.get('risk_score', 0)
        status = data.get('status', 'Complete')
        open_ports = data.get('open_ports', 0)
        vulnerabilities = data.get('vulnerabilities')
        
        if not title or not target:
            return jsonify({"error": "Missing required fields: title, target"}), 400
        
        scan = create_scan(request.user_id, title, target, risk_score, status, open_ports, vulnerabilities)
        
        if not scan:
            return jsonify({"error": "Scan with this title already exists"}), 409
        
        audit_logger.info(f"SCAN_CREATED: {title} - Risk Score: {risk_score}")
        return jsonify(scan), 201
    except Exception as e:
        logger.error(f"Error creating scan: {str(e)}")
        return jsonify({"error": "Failed to create scan"}), 500


@app.route('/api/scans/<int:scan_id>', methods=['GET'])
@require_api_key
def get_scan_api(scan_id):
    """Retrieve a single scan"""
    try:
        scan = get_scan(scan_id)
        
        if not scan:
            return jsonify({"error": "Scan not found"}), 404
        
        return jsonify(scan), 200
    except Exception as e:
        logger.error(f"Error retrieving scan {scan_id}: {str(e)}")
        return jsonify({"error": "Failed to retrieve scan"}), 500


@app.route('/api/scans/<int:scan_id>', methods=['PUT'])
@require_api_key
def update_scan_api(scan_id):
    """Update a scan"""
    try:
        data = request.get_json()
        scan = update_scan(scan_id, **data)
        
        if not scan:
            return jsonify({"error": "Scan not found"}), 404
        
        audit_logger.info(f"SCAN_UPDATED: ID {scan_id}")
        return jsonify(scan), 200
    except Exception as e:
        logger.error(f"Error updating scan {scan_id}: {str(e)}")
        return jsonify({"error": "Failed to update scan"}), 500


@app.route('/api/scans/<int:scan_id>', methods=['DELETE'])
@require_api_key
def delete_scan_api(scan_id):
    """Delete a scan"""
    try:
        delete_scan(scan_id)
        audit_logger.info(f"SCAN_DELETED: ID {scan_id}")
        return "", 204
    except Exception as e:
        logger.error(f"Error deleting scan {scan_id}: {str(e)}")
        return jsonify({"error": "Failed to delete scan"}), 500


@app.route('/api/scans/<int:scan_id>/results', methods=['POST'])
@require_api_key
def add_scan_result_api(scan_id):
    """Add a scan result (port/service)"""
    try:
        data = request.get_json()
        port = data.get('port')
        service = data.get('service')
        state = data.get('state')
        
        add_scan_result(scan_id, port, service, state)
        return "", 201
    except Exception as e:
        logger.error(f"Error adding scan result: {str(e)}")
        return jsonify({"error": "Failed to add scan result"}), 500


# Admin Endpoints

@app.route('/admin/users', methods=['GET'])
@require_admin
def get_users_admin():
    """Get all users (admin only)"""
    try:
        users = get_all_users()
        audit_logger.info(f"ADMIN_ACTION: User list accessed by admin {request.user_id}")
        return jsonify(users), 200
    except Exception as e:
        logger.error(f"Error retrieving users: {str(e)}")
        return jsonify({"error": "Failed to retrieve users"}), 500

@app.route('/admin/users/<int:user_id>', methods=['PUT'])
@require_admin
def update_user_admin(user_id):
    """Update user (admin only)"""
    try:
        data = request.get_json()
        is_admin = data.get('is_admin')
        
        if is_admin is not None:
            user = update_user(user_id, is_admin=is_admin)
            audit_logger.info(f"ADMIN_ACTION: User {user_id} admin status changed by admin {request.user_id}")
            return jsonify(user), 200
        
        return jsonify({"error": "Invalid update"}), 400
    except Exception as e:
        logger.error(f"Error updating user: {str(e)}")
        return jsonify({"error": "Failed to update user"}), 500

@app.route('/admin/users/<int:user_id>', methods=['DELETE'])
@require_admin
def delete_user_admin(user_id):
    """Delete user (admin only)"""
    try:
        if user_id == request.user_id:
            return jsonify({"error": "Cannot delete your own account"}), 400
        
        delete_user(user_id)
        audit_logger.info(f"ADMIN_ACTION: User {user_id} deleted by admin {request.user_id}")
        return jsonify({"success": True}), 200
    except Exception as e:
        logger.error(f"Error deleting user: {str(e)}")
        return jsonify({"error": "Failed to delete user"}), 500

@app.route('/admin/audit-logs', methods=['GET'])
@require_admin
def get_audit_logs_admin():
    """Get audit logs (admin only)"""
    try:
        with open('scanner_service/scan_audit.log', 'r') as f:
            logs = f.readlines()
        
        limit = request.args.get('limit', 100, type=int)
        logs = logs[-limit:]
        
        return jsonify({"logs": logs}), 200
    except FileNotFoundError:
        return jsonify({"logs": []}), 200
    except Exception as e:
        logger.error(f"Error retrieving audit logs: {str(e)}")
        return jsonify({"error": "Failed to retrieve audit logs"}), 500

@app.errorhandler(429)
def ratelimit_handler(e):
    """Handle rate limit exceeded"""
    audit_logger.warning(f"RATE_LIMIT_EXCEEDED: {request.remote_addr} - {e}")
    return jsonify({
        "error": "Rate limit exceeded. Maximum 2 requests per minute, 10 per hour."
    }), 429


if __name__ == "__main__":
    logger.info("="*60)
    logger.info("Starting Kioni Scanner Service on 127.0.0.1:6000 (internal only)")
    logger.info(f"API Key validation: {'ENABLED' if API_KEY else 'DISABLED (dev mode)'}")
    logger.info(f"Network whitelisting: {'ENABLED' if ALLOWED_NETWORKS else 'DISABLED (all targets allowed)'}")
    logger.info(f"Rate limiting: ENABLED (2/min, 10/hour)")
    logger.info("="*60)
    
    # Bind to localhost only for security
    app.run(host='127.0.0.1', port=6000, debug=False)
