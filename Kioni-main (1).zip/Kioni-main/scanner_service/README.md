# Kioni Scanner Service - Security Documentation

## Overview
The Kioni Scanner Service is a secure Flask-based API for network scanning using nmap. It includes multiple layers of security to prevent unauthorized access and abuse.

## Security Features

### 1. ✅ API Key Authentication
- All requests to `/scan` require a valid `X-API-KEY` header
- API key is stored securely in Replit Secrets (environment variable: `API_KEY`)
- Unauthorized requests are logged and rejected with 401 status

### 2. ✅ IP Whitelist Validation
- Only IP addresses/networks in the `ALLOWED_NETWORKS` list can be scanned
- Prevents unauthorized reconnaissance of external networks
- Scans to non-whitelisted targets are rejected with 403 status

### 3. ✅ Rate Limiting
- Global limits: 10 requests per hour, 2 per minute
- Per-endpoint limit for `/scan`: 5 scans per hour
- Prevents abuse and resource exhaustion attacks

### 4. ✅ Internal-Only Binding
- Service runs on `127.0.0.1:6000` (localhost only)
- NOT exposed to the public internet
- Only accessible from within your application (e.g., Next.js backend)

### 5. ✅ Comprehensive Logging
- All scan requests are logged with timestamps
- Logs include: target IP, source address, success/failure status
- Audit trail saved to `scanner_service/scan_audit.log`
- Failed authentication attempts are logged

## Configuration

### Required Secrets (Set in Replit Secrets)

1. **API_KEY** - Your secret authentication key
   - Example: `sk_live_abc123xyz789`
   - Required for service to start

2. **ALLOWED_NETWORKS** - Comma-separated list of allowed IP ranges
   - Example: `192.168.1.0/24,10.0.0.0/8`
   - Example single IP: `192.168.1.100`
   - Example multiple: `192.168.1.0/24,172.16.0.0/16,10.0.0.50`
   - **IMPORTANT**: Service will reject ALL scans if this is not configured

## Usage

### Starting the Service

```bash
python scanner_service/scanner.py
```

### Making Scan Requests

```bash
curl -X POST http://127.0.0.1:6000/scan \
  -H "Content-Type: application/json" \
  -H "X-API-KEY: your-api-key-here" \
  -d '{"target": "192.168.1.100"}'
```

### Health Check

```bash
curl http://127.0.0.1:6000/health
```

### Response Examples

**Successful Scan:**
```json
{
  "target": "192.168.1.100",
  "scan_time": 2.34,
  "results": {
    "scan": {...},
    "tcp": {...}
  }
}
```

**Unauthorized (Missing/Invalid API Key):**
```json
{
  "error": "Unauthorized"
}
```

**Forbidden (Target Not Whitelisted):**
```json
{
  "error": "Target not authorized for scanning",
  "message": "Only whitelisted IPs/networks can be scanned"
}
```

**Rate Limit Exceeded:**
```json
{
  "error": "429 Too Many Requests"
}
```

## Best Practices

1. **Never scan networks you don't own** - Always get written permission before scanning
2. **Keep API keys secret** - Never commit them to code or share publicly
3. **Limit ALLOWED_NETWORKS** - Only whitelist IPs/ranges you actually need to scan
4. **Monitor logs regularly** - Review `scan_audit.log` for suspicious activity
5. **Use from backend only** - Never expose the scanner service to frontend/public
6. **Rotate API keys** - Change your API_KEY periodically for better security

## Legal Notice

⚠️ **WARNING**: Network scanning may be illegal without proper authorization. This tool should ONLY be used to scan:
- Networks you own
- Systems you have explicit written permission to test
- Your own infrastructure for security assessments

Unauthorized network scanning may violate computer fraud and abuse laws in your jurisdiction.

## Integration with Next.js

Your Next.js API routes should proxy requests to the scanner service:

```javascript
// kioni/pages/api/scan.js
export default async function handler(req, res) {
  const response = await fetch('http://127.0.0.1:6000/scan', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-KEY': process.env.API_KEY
    },
    body: JSON.stringify({ target: req.body.target })
  });
  
  const data = await response.json();
  res.status(response.status).json(data);
}
```

This keeps your API_KEY on the server and never exposes it to clients.
