import sqlite3
import os
from datetime import datetime
import json
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "kioni_scans.db")

def init_db():
    """Initialize database with scans and users tables"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            is_admin BOOLEAN DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            target TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            status TEXT NOT NULL,
            open_ports INTEGER DEFAULT 0,
            vulnerabilities TEXT,
            timestamp TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scan_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER NOT NULL,
            port INTEGER,
            service TEXT,
            state TEXT,
            FOREIGN KEY (scan_id) REFERENCES scans (id) ON DELETE CASCADE
        )
    """)
    
    conn.commit()
    conn.close()

# User Functions
def create_user(email, username, password, is_admin=False):
    """Create a new user"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    now = datetime.now().isoformat()
    password_hash = generate_password_hash(password)
    
    try:
        cursor.execute("""
            INSERT INTO users (email, username, password_hash, is_admin, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (email, username, password_hash, 1 if is_admin else 0, now, now))
        
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        
        return get_user_by_id(user_id)
    except sqlite3.IntegrityError:
        conn.close()
        return None

def get_user_by_email(email):
    """Get user by email"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    
    return dict(user) if user else None

def get_user_by_username(username):
    """Get user by username"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()
    
    return dict(user) if user else None

def get_user_by_id(user_id):
    """Get user by ID"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, email, username, is_admin, created_at FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    return dict(user) if user else None

def verify_password(email, password):
    """Verify user password"""
    user = get_user_by_email(email)
    if user and check_password_hash(user['password_hash'], password):
        return user
    return None

# Admin Functions
def get_all_users():
    """Get all users (admin only)"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, email, username, is_admin, created_at FROM users ORDER BY created_at DESC")
    users = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return users

def update_user(user_id, **kwargs):
    """Update user record"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    allowed_fields = ['is_admin']
    fields = {k: v for k, v in kwargs.items() if k in allowed_fields}
    
    if not fields:
        conn.close()
        return get_user_by_id(user_id)
    
    fields['updated_at'] = datetime.now().isoformat()
    
    set_clause = ", ".join([f"{k} = ?" for k in fields.keys()])
    values = list(fields.values()) + [user_id]
    
    cursor.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
    conn.commit()
    conn.close()
    
    return get_user_by_id(user_id)

def delete_user(user_id):
    """Delete user and their scans"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM scans WHERE user_id = ?", (user_id,))
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
    
    return True

def get_all_scans(user_id=None):
    """Retrieve all scans, optionally filtered by user"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if user_id:
        cursor.execute("SELECT * FROM scans WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
    else:
        cursor.execute("SELECT * FROM scans ORDER BY created_at DESC")
    
    scans = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return scans

def get_scan(scan_id):
    """Retrieve a single scan by ID"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
    scan = cursor.fetchone()
    
    if scan:
        # Get scan results
        cursor.execute("SELECT * FROM scan_results WHERE scan_id = ?", (scan_id,))
        results = [dict(row) for row in cursor.fetchall()]
        scan = dict(scan)
        scan['results'] = results
    
    conn.close()
    return scan

def create_scan(user_id, title, target, risk_score, status, open_ports=0, vulnerabilities=None):
    """Create a new scan record"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    now = datetime.now().isoformat()
    
    try:
        cursor.execute("""
            INSERT INTO scans (user_id, title, target, risk_score, status, open_ports, vulnerabilities, timestamp, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, title, target, risk_score, status, open_ports, json.dumps(vulnerabilities or []), now, now, now))
        
        conn.commit()
        scan_id = cursor.lastrowid
        conn.close()
        
        return get_scan(scan_id)
    except sqlite3.IntegrityError:
        conn.close()
        return None

def update_scan(scan_id, **kwargs):
    """Update a scan record"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    allowed_fields = ['title', 'target', 'risk_score', 'status', 'open_ports', 'vulnerabilities']
    fields = {k: v for k, v in kwargs.items() if k in allowed_fields}
    
    if not fields:
        conn.close()
        return get_scan(scan_id)
    
    fields['updated_at'] = datetime.now().isoformat()
    
    set_clause = ", ".join([f"{k} = ?" for k in fields.keys()])
    values = list(fields.values()) + [scan_id]
    
    cursor.execute(f"UPDATE scans SET {set_clause} WHERE id = ?", values)
    conn.commit()
    conn.close()
    
    return get_scan(scan_id)

def delete_scan(scan_id):
    """Delete a scan record"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
    conn.commit()
    conn.close()
    
    return True

def add_scan_result(scan_id, port, service, state):
    """Add a scan result (port/service)"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO scan_results (scan_id, port, service, state)
        VALUES (?, ?, ?, ?)
    """, (scan_id, port, service, state))
    
    conn.commit()
    conn.close()

# Initialize database on import
init_db()
